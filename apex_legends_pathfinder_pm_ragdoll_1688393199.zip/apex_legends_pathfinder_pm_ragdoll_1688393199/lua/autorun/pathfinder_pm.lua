player_manager.AddValidModel( "Pathfinder", "models/n7legion/apexlegends/pathfinder_pm.mdl" )
player_manager.AddValidHands("Pathfinder", "models/weapons/arms/v_arms_pathfinder.mdl", 0, "00000000")
list.Set( "PlayerOptionsModel",  "Pathfinder", "models/n7legion/apexlegends/pathfinder_pm.mdl" )
